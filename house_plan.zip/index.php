<?php
header('Location: controllers/home.php');
?>