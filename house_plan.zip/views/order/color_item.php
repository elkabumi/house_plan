<div class="color_item">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr height="80">
    <td align="center" width="5%"><div class="color_item_kosong"><?= get_item_kosong($building_id) ?></div></td>
    <td align="left" width="5%">&nbsp;</td>
    <td align="left" width="40%">Kosong</td>
    <td align="center" width="5%"><div class="color_item_terjual"><?= get_item_terjual($building_id) ?></div></td>
    <td align="center" width="5%">&nbsp;</td>
    <td align="left" width="40%">Terjual</td>
    </tr>
  </table>
</div>